var portraitText = `My name is Joe Taylor. I am seventeen, I live in England, and I am in the second year of A-Levels, which mostly means I spend my evenings writing Python and my mornings wishing I had gone to bed earlier.

Computer Science is the subject I would choose again without thinking about it. My NEA project has taken over more of my life than I expected. I have rewritten the database layer three times, and each version was the one I was sure would be final. I like the moment a program stops being a pile of functions and starts behaving like something with its own logic. I also like finding the bug that has been hiding in plain sight for two days, although I like it less while I am still looking.

Outside of school I build small websites, mostly to see whether an idea works. Some of them are useful. Most of them are not, but I learn something from every one, usually about what not to do next time. This page is one of those experiments.

The words you are reading are wearing away. Every hour a few letters fade, then lose their shape, then disappear entirely. Nothing here is permanent unless somebody decides it is worth keeping. If you see a word that has started to go, you can click it and put it back. Your repairs are shared with everyone who visits, so the state of this page is a record of how much attention it has been given.

I find that idea more honest than a normal about page. People are not fixed descriptions. We are kept up by the people around us, and we drift when nobody is paying attention.

If you have read this far, thank you. Repair a word on your way out.`;

var STAGE_INTACT = 0;
var STATE_KEY = "state";
var REPAIRS_PER_HOUR = 20;
var HOUR_MS = 60 * 60 * 1e3;
var characters = Array.from(portraitText);
function hashText(text) {
  let hash = 2166136261;
  for (let i = 0; i < text.length; i++) {
    hash ^= text.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(16).padStart(8, "0");
}
var textHash = hashText(portraitText);
var isWhitespace = (ch) => /\s/.test(ch);
var wordRanges = (() => {
  const ranges = [];
  let start = -1;
  characters.forEach((ch, i) => {
    if (isWhitespace(ch)) {
      if (start !== -1) ranges.push([start, i]);
      start = -1;
    } else if (start === -1) {
      start = i;
    }
  });
  if (start !== -1) ranges.push([start, characters.length]);
  return ranges;
})();
function encodeCells(cells) {
  let binary = "";
  for (const byte of cells) binary += String.fromCharCode(byte);
  return btoa(binary);
}
function decodeCells(encoded) {
  const binary = atob(encoded);
  const cells = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) cells[i] = binary.charCodeAt(i);
  return cells;
}
function isIntact(cells) {
  return cells.every((stage) => stage === STAGE_INTACT);
}
function isWordDamaged(cells, wordIndex) {
  const [start, end] = wordRanges[wordIndex];
  for (let i = start; i < end; i++) {
    if (cells[i] !== STAGE_INTACT) return true;
  }
  return false;
}
function repairWord(cells, wordIndex) {
  const [start, end] = wordRanges[wordIndex];
  cells.fill(STAGE_INTACT, start, end);
}
function freshState(previous) {
  return {
    textHash,
    cells: new Uint8Array(characters.length),
    repairs: previous?.repairs ?? 0,
    lastIntact: (/* @__PURE__ */ new Date()).toISOString()
  };
}
async function loadState(kv) {
  const stored = await kv.get(STATE_KEY, "json");
  if (!stored || stored.textHash !== textHash) return freshState(stored);
  return {
    textHash: stored.textHash,
    cells: decodeCells(stored.cells),
    repairs: stored.repairs,
    lastIntact: stored.lastIntact
  };
}
async function saveState(kv, state) {
  await kv.put(
    STATE_KEY,
    JSON.stringify({
      textHash: state.textHash,
      cells: encodeCells(state.cells),
      repairs: state.repairs,
      lastIntact: state.lastIntact
    })
  );
}
function currentHourBucket(now = Date.now()) {
  return Math.floor(now / HOUR_MS);
}
function hourBucketEnd(bucket) {
  return new Date((bucket + 1) * HOUR_MS).toISOString();
}
async function hashVisitor(ip, salt) {
  const data = new TextEncoder().encode(`${salt}:${ip}`);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return Array.from(
    new Uint8Array(digest).slice(0, 16),
    (byte) => byte.toString(16).padStart(2, "0")
  ).join("");
}
function rateKey(visitorHash, bucket) {
  return `rate:${visitorHash}:${bucket}`;
}
async function readAllowance(kv, visitorHash, bucket) {
  const used = Number(await kv.get(rateKey(visitorHash, bucket))) || 0;
  return Math.max(0, REPAIRS_PER_HOUR - used);
}
function publicState(state, allowance, bucket) {
  return {
    text: portraitText,
    cells: encodeCells(state.cells),
    repairs: state.repairs,
    intact: isIntact(state.cells),
    lastIntact: state.lastIntact,
    allowance,
    allowanceResetsAt: hourBucketEnd(bucket)
  };
}

var RATE_KEY_TTL_SECONDS = 2 * 60 * 60;
function parseWords(body) {
  if (!body || !Array.isArray(body.words)) return null;
  const words = [...new Set(body.words)];
  if (words.length === 0 || words.length > REPAIRS_PER_HOUR) return null;
  const valid = words.every((word) => Number.isInteger(word) && word >= 0 && word < wordRanges.length);
  return valid ? words : null;
}
async function handleRepair(request, env) {
  if (!env.IP_SALT) {
    return Response.json({ error: "Server is missing IP_SALT." }, { status: 500 });
  }
  const words = parseWords(await request.json().catch(() => null));
  if (!words) {
    return Response.json({ error: "Send a list of word positions to repair." }, { status: 400 });
  }
  const bucket = currentHourBucket();
  const visitorHash = await hashVisitor(request.headers.get("CF-Connecting-IP") ?? "local", env.IP_SALT);
  const [state, allowance] = await Promise.all([
    loadState(env.PORTRAIT),
    readAllowance(env.PORTRAIT, visitorHash, bucket)
  ]);
  const damaged = words.filter((word) => isWordDamaged(state.cells, word));
  const accepted = damaged.slice(0, allowance);
  const remaining = allowance - accepted.length;
  if (accepted.length > 0) {
    accepted.forEach((word) => repairWord(state.cells, word));
    state.repairs += accepted.length;
    if (isIntact(state.cells)) state.lastIntact = (/* @__PURE__ */ new Date()).toISOString();
    await Promise.all([
      saveState(env.PORTRAIT, state),
      env.PORTRAIT.put(rateKey(visitorHash, bucket), String(REPAIRS_PER_HOUR - remaining), {
        expirationTtl: RATE_KEY_TTL_SECONDS
      })
    ]);
  }
  const status = damaged.length > accepted.length ? 429 : 200;
  return Response.json(
    { ...publicState(state, remaining, bucket), repaired: accepted.length, refused: damaged.length - accepted.length },
    { status, headers: { "Cache-Control": "no-store" } }
  );
}

async function handleState(request, env) {
  const bucket = currentHourBucket();
  const visitorHash = await hashVisitor(request.headers.get("CF-Connecting-IP") ?? "local", env.IP_SALT);
  const [state, allowance] = await Promise.all([
    loadState(env.PORTRAIT),
    readAllowance(env.PORTRAIT, visitorHash, bucket)
  ]);
  return Response.json(publicState(state, allowance, bucket), {
    headers: { "Cache-Control": "no-store" }
  });
}

// src/pages-entry.js
var routes = {
  "GET /api/state": handleState,
  "POST /api/repair": handleRepair
};
var pages_entry_default = {
  async fetch(request, env) {
    const { pathname } = new URL(request.url);
    const handler = routes[`${request.method} ${pathname}`];
    if (handler) return handler(request, env);
    return env.ASSETS.fetch(request);
  }
};
export {
  pages_entry_default as default
};
